package com.cg.flatRental.exceptions;

public class FlatNotFoundException extends Exception {
	public FlatNotFoundException() {
	}
	public FlatNotFoundException(String msg) {
		super(msg);
	}
}
