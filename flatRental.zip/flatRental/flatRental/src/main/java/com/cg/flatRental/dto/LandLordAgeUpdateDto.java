package com.cg.flatRental.dto;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

public class LandLordAgeUpdateDto {
	
	private long userId;
	@Min(value = 18, message = "Age must be greater than 18 years!")
	@Max(value = 120, message = "Age must not be greater than 120 years!")
	private int landLordAge;
	
	public long getUserId() {
		return userId;
	}
	public void setUserId(long userId) {
		this.userId = userId;
	}
	public int getLandLordAge() {
		return landLordAge;
	}
	public void setLandLordAge(int landLordAge) {
		this.landLordAge = landLordAge;
	}
}
