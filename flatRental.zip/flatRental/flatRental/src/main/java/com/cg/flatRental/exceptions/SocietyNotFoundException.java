package com.cg.flatRental.exceptions;

public class SocietyNotFoundException extends Exception {
	public SocietyNotFoundException() {
	}
	
	public SocietyNotFoundException(String msg) {
	}
}
