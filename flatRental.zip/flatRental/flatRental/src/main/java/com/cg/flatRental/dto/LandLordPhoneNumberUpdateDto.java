package com.cg.flatRental.dto;

public class LandLordPhoneNumberUpdateDto {
	
	private long userId;
	private long landLordPhoneNumber;
	
	public long getUserId() {
		return userId;
	}
	public void setUserId(long userId) {
		this.userId = userId;
	}
	public long getLandLordPhoneNumber() {
		return landLordPhoneNumber;
	}
	public void setLandLordPhoneNumber(long landLordPhoneNumber) {
		this.landLordPhoneNumber = landLordPhoneNumber;
	}
}
