package com.cg.flatRental.dto;

import javax.validation.constraints.NotBlank;

public class SocietyNameDto {
	private int societyId;
	@NotBlank(message = "Society Name cannot be empty")
	private String societyName;
	
	public int getSocietyId() {
		return societyId;
	}
	public void setSocietyId(int societyId) {
		this.societyId = societyId;
	}
	public String getSocietyName() {
		return societyName;
	}
	public void setSocietyName(String societyName) {
		this.societyName = societyName;
	}
}
