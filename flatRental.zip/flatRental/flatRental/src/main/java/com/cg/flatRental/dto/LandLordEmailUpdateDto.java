package com.cg.flatRental.dto;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;

public class LandLordEmailUpdateDto {
	
	private long userId;
	@NotBlank(message = "EmailId cannot be empty")
	@Email(message = "Not the proper Email ID format! enter again")
	private String landLordEmailId;
	
	public long getUserId() {
		return userId;
	}
	public void setUserId(long userId) {
		this.userId = userId;
	}
	public String getLandLordEmailId() {
		return landLordEmailId;
	}
	public void setLandLordEmailId(String landLordEmailId) {
		this.landLordEmailId = landLordEmailId;
	}
}
