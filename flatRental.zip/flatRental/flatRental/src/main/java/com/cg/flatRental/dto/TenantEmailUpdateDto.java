package com.cg.flatRental.dto;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;

public class TenantEmailUpdateDto {
	
	private long userId;
	@NotBlank(message = "EmailId cannot be empty")
	@Email(message = "Not the proper Email ID format! enter again")
	private String emailId;
	
	public long getUserId() {
		return userId;
	}
	public void setUserId(long userId) {
		this.userId = userId;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
}
