package com.cg.flatRental.iservice;

public interface IUserService {
	public boolean isValidUser(String username, String password);
}