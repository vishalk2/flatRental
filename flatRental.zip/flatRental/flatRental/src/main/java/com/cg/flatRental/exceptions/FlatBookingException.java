package com.cg.flatRental.exceptions;

public class FlatBookingException extends Exception {
	public FlatBookingException() {
	}
	
	public FlatBookingException(String msg) {
		super(msg);
	}
}
