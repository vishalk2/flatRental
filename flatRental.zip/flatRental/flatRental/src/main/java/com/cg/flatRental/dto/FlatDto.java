package com.cg.flatRental.dto;

import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

public class FlatDto {
	
	private long landlordId;
	
	@Min(value = 1, message = "Flat number must be greater than 0!")
	@Max(value = 1000000000, message = "Flat number cannot be greater than 1000000000!")
	private int flatNo;
	@NotBlank(message = "Flat Type cannot be empty")
	private String flatType;
	@Min(value = 1, message = "Rental Cost must be greater than 0!")
	@Max(value = 1000000000, message = "Rental Cost cannot be greater than 1000000000!")
	private double rentalCost;
	
	private int societyId;
	
	@NotBlank(message = "Area cannot be empty")
	private String area;
	@NotBlank(message = "City cannot be empty")
	private String city;
	@NotBlank(message = "State cannot be empty")
	private String state;
	@NotBlank(message = "Country cannot be empty")
	private String country;
	private int pincode;
	
	private boolean garden;
	private boolean swimmingPool;
	private boolean carParking;
	private String houseFacing;
	private double squareFeet;
	
	public FlatDto() {
	}
	
	public FlatDto(long landlordId,
			@Min(value = 1, message = "Flat number must be greater than 0!") @Max(value = 1000000000, message = "Flat number cannot be greater than 1000000000!") int flatNo,
			@NotBlank(message = "Flat Type cannot be empty") String flatType,
			@Min(value = 1, message = "Rental Cost must be greater than 0!") @Max(value = 1000000000, message = "Rental Cost cannot be greater than 1000000000!") double rentalCost,
			int societyId, @NotBlank(message = "Area cannot be empty") String area,
			@NotBlank(message = "City cannot be empty") String city,
			@NotBlank(message = "State cannot be empty") String state,
			@NotBlank(message = "Country cannot be empty") String country,
			int pincode, boolean garden, boolean swimmingPool,
			boolean carParking, String houseFacing, double squareFeet) {
		super();
		this.landlordId = landlordId;
		this.flatNo = flatNo;
		this.flatType = flatType;
		this.rentalCost = rentalCost;
		this.societyId = societyId;
		this.area = area;
		this.city = city;
		this.state = state;
		this.country = country;
		this.pincode = pincode;
		this.garden = garden;
		this.swimmingPool = swimmingPool;
		this.carParking = carParking;
		this.houseFacing = houseFacing;
		this.squareFeet = squareFeet;
	}

	public long getLandlordId() {
		return landlordId;
	}
	public void setLandlordId(long landlordId) {
		this.landlordId = landlordId;
	}
	public int getFlatNo() {
		return flatNo;
	}
	public void setFlatNo(int flatNo) {
		this.flatNo = flatNo;
	}
	public String getFlatType() {
		return flatType;
	}
	public void setFlatType(String flatType) {
		this.flatType = flatType;
	}
	public double getRentalCost() {
		return rentalCost;
	}
	public void setRentalCost(double rentalCost) {
		this.rentalCost = rentalCost;
	}
	public int getSocietyId() {
		return societyId;
	}
	public void setSocietyId(int societyId) {
		this.societyId = societyId;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public int getPincode() {
		return pincode;
	}
	public void setPincode(int pincode) {
		this.pincode = pincode;
	}
	public boolean isGarden() {
		return garden;
	}
	public void setGarden(boolean garden) {
		this.garden = garden;
	}
	public boolean isSwimmingPool() {
		return swimmingPool;
	}
	public void setSwimmingPool(boolean swimmingPool) {
		this.swimmingPool = swimmingPool;
	}
	public boolean isCarParking() {
		return carParking;
	}
	public void setCarParking(boolean carParking) {
		this.carParking = carParking;
	}
	public String getHouseFacing() {
		return houseFacing;
	}
	public void setHouseFacing(String houseFacing) {
		this.houseFacing = houseFacing;
	}
	public double getSquareFeet() {
		return squareFeet;
	}
	public void setSquareFeet(double squareFeet) {
		this.squareFeet = squareFeet;
	}
}
