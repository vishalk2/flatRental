package com.cg.flatRental.exceptions;

public class FlatAvailabilityException extends Exception {
	
	public FlatAvailabilityException() {
	}
	
	public FlatAvailabilityException(String msg) {
		super(msg);
	}
}
