package com.cg.flatRental;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlatRentalApplicationTests {

	@Test
	void contextLoads() {
	}

}
