import React from "react";
import FlatCardA from "../../Flat/Component/FlatCardA";
import Footer from "../../Homepage/Footer";
import Reserva from "../../Homepage/Reserva";
import AdminNavbar from "./AdminNavbar";
import "bootstrap/dist/css/bootstrap.css";
import "./../../css/SocietyList.css";
import FlatASection from "../../Flat/Component/FlatASection";

function AdminFlatList() {
  return (
    <div>
      <AdminNavbar />

      <Reserva />

      <FlatASection /> {/* <FlatSection /> */}

      <FlatCardA />

      <Footer />
    </div>
  );
}

export default AdminFlatList;
