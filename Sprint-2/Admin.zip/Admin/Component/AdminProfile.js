import React from 'react';
import Profile from '../../User/Component/Profile';
import AdminNavbar from './AdminNavbar';

function AdminProfile() {
    return (
        <div>
            <AdminNavbar/>
            <Profile/>
        </div>
    );
}

export default AdminProfile;