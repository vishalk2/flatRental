import React from "react";
import Flat from "../../Flat/Component/Flat";
import Footer from "../../Homepage/Footer";
import AdminNavbar from "./AdminNavbar";
import { Button } from "react-bootstrap";
import CarouselSection from "../../Homepage/CarouselSection";

function AdminFlat() {
  return (
    <div>
      <AdminNavbar />

      <Flat />

      <section className="container">
        <div id="landlord-society-section">
          <Button variant="outline-danger" href="/flat/admin/approval">
            Approve Flat
          </Button>{" "}
          <Button>Remove Flat</Button>
        </div>
        <hr style={{ width: "100%", margin: "auto", height: "2px" }} />
      </section>

      <CarouselSection />

      <Footer />
    </div>
  );
}

export default AdminFlat;
