import React from "react";
import "bootstrap/dist/css/bootstrap.css";
import "./../../css/SocietyList.css";
import SocietyCardA from "./../../Society/Component/SocietyCardA";
import Footer from "../../Homepage/Footer";
import AdminNavbar from "./AdminNavbar";
import Reserva from "../../Homepage/Reserva";

function AdminSocietyList() {
  return (
    <div>
      <AdminNavbar />

      <Reserva />

      <section id="society-list-section">
        <hr style={{ width: "45%", margin: "auto", height: "7px" }} />
        <div className="container">
          <h1 id="society-header">~ ALL SOCIETIES ~</h1>
        </div>
      </section>

      <SocietyCardA />
      <SocietyCardA />

      <Footer />
    </div>
  );
}

export default AdminSocietyList;
