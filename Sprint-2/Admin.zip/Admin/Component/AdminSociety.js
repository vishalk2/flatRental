import React from "react";
import AdminNavbar from "./AdminNavbar";
import { Button } from "react-bootstrap";
import Footer from "../../Homepage/Footer";
import Society from "../../Society/Component/Society";
import "./../../css/Society.css";

function AdminSociety() {
  return (
    <div>
      <AdminNavbar />

      <Society />

      <section className="container">
        <div id="landlord-society-section">
          <Button variant="outline-danger" href="/society/admin/approval">
            Approve Society
          </Button>{" "}
          <Button variant="outline-danger">
            Remove Society
          </Button>
        </div>
        <hr style={{ width: "100%", margin: "auto", height: "2px" }} />
      </section>

      <Footer />
    </div>
  );
}

export default AdminSociety;
