import React from "react";
import Footer from "../../Homepage/Footer";
import Reserva from "../../Homepage/Reserva";
import AdminNavbar from "./AdminNavbar";
import Button from "react-bootstrap/Button";
import CarouselSection from "../../Homepage/CarouselSection";

function AdminHome() {
  return (
    <div>
      <AdminNavbar />

      <Reserva />
      <hr style={{ width: "45%", margin: "auto", height: "7px" }} />

      <CarouselSection />
      <br />
      <hr style={{ width: "45%", margin: "auto", height: "7px" }} />
      <br />
      <div className="container mb-2">
        <Button variant="primary" size="lg" href="/societies/admin">
          All Societies
        </Button>{" "}
        <Button variant="primary" size="lg" href="/flats/admin">
          All Flats
        </Button>
      </div>
      <br />
      <hr style={{ width: "45%", margin: "auto", height: "7px" }} />
      <br />
      <Reserva />
      <Footer />
    </div>
  );
}

export default AdminHome;
