import React from "react";
import { Avatar } from "@mui/material";
import { red } from "@mui/material/colors";
import Container from "react-bootstrap/Container";
import Nav from "react-bootstrap/Nav";
import Navbar from "react-bootstrap/Navbar";
import NavDropdown from "react-bootstrap/NavDropdown";
import "bootstrap/dist/css/bootstrap.css";
import "./../../css/Landlord.css";

function AdminNavbar() {
  return (
    <div>
      <Navbar bg="light" expand="lg" id="landlord-navbar" fixed="top">
        <Container>
          <Navbar.Brand style={{ color: "white" }}>
            <i>~ RESERVA ~</i>
          </Navbar.Brand>
          <Navbar.Toggle aria-controls="landlord-navbar-nav" />
          <Navbar.Collapse id="landlord-navbar-nav">
            <Nav className="ms-auto">
              <Avatar sx={{ bgcolor: red[500] }}>A</Avatar>
              <NavDropdown title="" id="landlord-nav-dropdown">
                <NavDropdown.Header>RESERVA</NavDropdown.Header>
                <NavDropdown.Item href="/home/admin">Home</NavDropdown.Item>
                <NavDropdown.Item href="/societies/admin">
                  Societies
                </NavDropdown.Item>
                <NavDropdown.Item href="/flats/admin">Flats</NavDropdown.Item>
                <NavDropdown.Divider />
                <NavDropdown.Item href="/logout">Logout</NavDropdown.Item>
              </NavDropdown>
            </Nav>
          </Navbar.Collapse>
        </Container>
      </Navbar>
    </div>
  );
}

export default AdminNavbar;
